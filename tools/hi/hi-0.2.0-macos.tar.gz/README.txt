hi 0.2.0 — the Hyper Island plugin tool.

  ./hi help

Keep lucide.ttf beside hi: it checks plugins' icon names against it.
