hi 0.1.1 — the Hyper Island plugin tool.

  ./hi help

Keep lucide.ttf beside hi: it checks plugins' icon names against it.
